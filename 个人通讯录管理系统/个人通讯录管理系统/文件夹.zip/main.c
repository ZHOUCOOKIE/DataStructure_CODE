#define _CRT_SECURE_NO_WARNINGS
#include "contacts.h"
#include <stdio.h>
enum Option
{
	PRINT,
	SEARCH,
	ADD,
	MODIFY,
	DELETE,
	SAVEANDEXIT,
	EXITBUTNOSAVE
};


int main()
{
	Contact* L ;
	int input = 0;
	do
	{
		Menu();
		printf("��ѡ���ܣ�");
		scanf("%d", &input);
		switch (input)
		{
		case PRINT:
			Print(L);
			break;
		case SEARCH:
			break;
		case ADD:
			Add(L);
			break;
		case MODIFY:
			break;
		case DELETE:
			break;
		case SAVEANDEXIT:
			break;
		case EXITBUTNOSAVE:
			break;
		default:
			break;
		}
	} while (input);
	return 0;
}